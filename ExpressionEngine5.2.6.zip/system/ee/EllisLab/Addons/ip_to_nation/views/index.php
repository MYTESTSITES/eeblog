<div class="box mb">
	<?php $this->embed('ee:_shared/form', $ip_search)?>
</div>

<div class="box">
	<?php $this->embed('ee:_shared/form', $banned_list)?>
</div>
