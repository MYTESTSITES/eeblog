<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Metaweblog_api',
	'description' => '',
	'version'     => '2.3.0',
	'namespace'   => 'EllisLab\Addons\MetaweblogApi',
	'settings_exist' => TRUE,
);
